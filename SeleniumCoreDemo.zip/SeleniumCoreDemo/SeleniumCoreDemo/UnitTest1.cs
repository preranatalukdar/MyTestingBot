using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;

namespace SeleniumCoreDemo
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void Test1()

        {
            IWebDriver webDriver = new EdgeDriver();
            //Sign in into Amazon.ca
            webDriver.Navigate().GoToUrl("https://www.amazon.ca/");
            webDriver.FindElement(By.Id("nav-link-accountList-nav-line-1")).Click();
            webDriver.FindElement(By.Name("email")).SendKeys("prerana.talukdar@outlook.com");
            webDriver.FindElement(By.Id("continue")).Click();
            webDriver.FindElement(By.Name("password")).SendKeys("AduBuggu@123#");
            webDriver.FindElement(By.Id("signInSubmit")).Click();
            //Search Items in the search box
            webDriver.FindElement(By.Id("twotabsearchtextbox")).SendKeys("bags for women");
            webDriver.FindElement(By.Id("nav-search-submit-button")).Submit();
            //Selection of the item
            webDriver.FindElement(By.LinkText("Travel Duffel Bag,Sports Tote Gym Bag,Shoulder Weekender Overnight Bag for Women")).Click();
            //Adding it to the wishlist
            webDriver.FindElement(By.Id("add-to-wishlist-button-submit")).Click();
            //View wishlist
            webDriver.Navigate().GoToUrl("https://www.amazon.ca/hz/wishlist/ls/QRLB6609UVYT?ref_=wl_dp_view_your_list");
        }

    }
}